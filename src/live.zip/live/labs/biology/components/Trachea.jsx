import React from "react"

export default function Trachea({position=[0,1,0]}){

return(

<mesh position={position}>

<cylinderGeometry args={[0.15,0.15,2,32]} />

<meshStandardMaterial color="#dddddd" />

</mesh>

)

}