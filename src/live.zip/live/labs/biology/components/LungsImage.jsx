import { useLoader } from "@react-three/fiber"
import { TextureLoader } from "three"

export default function LungsImage(){

const texture = useLoader(TextureLoader, "/src/live/labs/biology/assets/lungs.png")

return (

<mesh position={[0,0,0]}>
  <planeGeometry args={[6,8]} />
  <meshBasicMaterial map={texture} />
</mesh>

)

}