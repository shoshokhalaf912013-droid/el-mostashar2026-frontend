import { Canvas } from "@react-three/fiber"
import RespiratoryScene from "./scenes/RespiratoryScene"

export default function BiologyLab({ close }) {

return(

<div className="biologyLabLayer">

<button onClick={close}>X</button>

<div style={{width:"100%",height:"100%"}}>

<Canvas camera={{ position:[0,0,5], fov:50 }}>

<RespiratoryScene />

</Canvas>

</div>

</div>

)

}