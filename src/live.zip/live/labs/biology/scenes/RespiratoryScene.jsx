import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { OrbitControls } from "@react-three/drei"

function Lung({ position, scaleX = 1 }) {
  return (
    <group position={position} scale={[scaleX, 1, 1]}>
      <mesh>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial color="#ff8fa3" roughness={0.5} metalness={0.1} />
      </mesh>

      <mesh position={[0, -0.6, 0]}>
        <sphereGeometry args={[0.9, 32, 32]} />
        <meshStandardMaterial color="#ff8fa3" />
      </mesh>
    </group>
  )
}

function Trachea() {
  return (
    <mesh position={[0, 1.2, 0]}>
      <cylinderGeometry args={[0.2, 0.25, 2, 32]} />
      <meshStandardMaterial color="#ffb3c1" />
    </mesh>
  )
}

export default function RespiratoryScene() {

  const lungsRef = useRef()

  useFrame(({ clock }) => {

    const t = clock.getElapsedTime()

    const breath = 1 + Math.sin(t * 2) * 0.08

    if (lungsRef.current) {
      lungsRef.current.scale.set(breath, breath, breath)
    }

  })

  return (
    <>
      <ambientLight intensity={1.3} />
      <directionalLight position={[3, 4, 5]} intensity={2} />

      <group ref={lungsRef}>

        <Lung position={[-1.1, 0, 0]} scaleX={0.9} />

        <Lung position={[1.1, 0, 0]} scaleX={1} />

        <Trachea />

      </group>

      <OrbitControls enableZoom={true} />

    </>
  )
}